// Structured content from the Mosquito & Insect Lamp Presentation PDF
export const PRESENTATION_DATA = {
  title: "Mosquito & Insect Lamps",
  subtitle: "A simple, clear guide to how modern ultraviolet bug lamps eliminate flying pests safely without harmful chemicals or toxic sprays.",
  
  wavelengths: [
    { nm: 365, label: "Deep UV-A", attraction: 94, color: "#9b51e0", glow: "rgba(155, 81, 224, 0.9)", desc: "Optimal peak wavelength for compound insect eyes. Emits over 5x more attraction than household room lighting." },
    { nm: 395, label: "Near-UV Light", attraction: 71, color: "#7928ca", glow: "rgba(121, 40, 202, 0.8)", desc: "High attraction spectrum, common in economy UV LED tubes." },
    { nm: 450, label: "Blue Light", attraction: 43, color: "#0070f3", glow: "rgba(0, 112, 243, 0.7)", desc: "Visible blue spectrum; captures mid-range phototactic attraction." },
    { nm: 550, label: "Green Light", attraction: 18, color: "#10b981", glow: "rgba(16, 185, 129, 0.6)", desc: "Low phototactic response for nocturnal biting mosquitoes; poor lure." }
  ],

  trapTypes: {
    zapper: {
      name: "High-Voltage Electric Grid Zapper",
      power: "15W – 40W",
      mechanism: "Electrified galvanized metal wire mesh (1500V - 3000V)",
      sound: "Audible Zap (>65 dB)",
      soundValue: 68,
      recommended: "Patios, sheds, balconies, large open rooms",
      efficiency: 96,
      badge: "High Impact",
      accent: "#e056fd",
      desc: "Delivers an instant electric shock as soon as an insect makes contact. Instant audible zap, zero moving parts, long durability."
    },
    suction: {
      name: "Quiet Vortex Suction Fan",
      power: "5W – 12W",
      mechanism: "Whisper-quiet fan creates downward vortex vacuum draft",
      sound: "Whisper Quiet (<25 dB)",
      soundValue: 22,
      recommended: "Bedrooms, nurseries, dining areas, desks",
      efficiency: 89,
      badge: "Whisper Silent",
      accent: "#00f5ff",
      desc: "Traps insects whole without scattering burnt particles or sparks. Ideal for peaceful sleep and clean environments."
    },
    sticky: {
      name: "Hygienic Sticky Pad Trap",
      power: "8W – 20W",
      mechanism: "Non-drying glue pad beneath UV lamp",
      sound: "Completely Silent (0 dB)",
      soundValue: 0,
      recommended: "Kitchens, cafes, pantries, food prep",
      efficiency: 82,
      badge: "Food Safe",
      accent: "#f59e0b",
      desc: "Zero noise, zero splatter, 100% hygienic and compliant with sanitary food service requirements."
    },
    solar: {
      name: "Solar Outdoor Lamp",
      power: "3W – 10W",
      mechanism: "Rechargeable solar battery + electro-mesh with daylight sensor",
      sound: "Soft Zap (~50 dB)",
      soundValue: 48,
      recommended: "Gardens, lawns, camping, perimeter defense",
      efficiency: 86,
      badge: "Off-Grid Eco",
      accent: "#10b981",
      desc: "Autonomous outdoor pest perimeter defense powered by daylight charging."
    }
  },

  insectSpecies: [
    {
      id: "mosquito",
      name: "Mosquitoes & Midges",
      share: 42,
      color: "#a855f7",
      speed: 1.3,
      size: 1.0,
      thermalAffinity: 0.95,
      lightAffinity: 0.85,
      erraticness: 0.8,
      desc: "Target human body warmth (37°C) & CO2, lured off-course by 365nm UV lamp."
    },
    {
      id: "fruitfly",
      name: "Fruit Flies & Drain Gnats",
      share: 28,
      color: "#06b6d4",
      speed: 1.7,
      size: 0.7,
      thermalAffinity: 0.3,
      lightAffinity: 0.95,
      erraticness: 0.9,
      desc: "Rapid darting flight; extremely responsive to light contrast gradient."
    },
    {
      id: "housefly",
      name: "Houseflies & Blowflies",
      share: 18,
      color: "#10b981",
      speed: 2.2,
      size: 1.4,
      thermalAffinity: 0.5,
      lightAffinity: 0.75,
      erraticness: 0.6,
      desc: "Fast, agile zig-zag flyers; susceptible to high-voltage grid & suction vortex."
    },
    {
      id: "moth",
      name: "Night Moths & Beetles",
      share: 12,
      color: "#f59e0b",
      speed: 1.1,
      size: 1.8,
      thermalAffinity: 0.2,
      lightAffinity: 1.0,
      erraticness: 0.4,
      desc: "Transverse phototaxis orientation results in tight spiral flight directly into grid."
    }
  ],

  anatomyParts: [
    {
      id: "uv_core",
      title: "UV Light Source (365nm)",
      desc: "Energy-efficient purple LEDs or UV quartz tubes emitting exact 365nm light tuned to insects' compound eyes."
    },
    {
      id: "grid_or_fan",
      title: "Electrified Wire Grid / Suction Vortex",
      desc: "Internal galvanized wire cage charged with voltage (1500V-3000V) or silent aerodynamic vortex impeller creating down-draft."
    },
    {
      id: "housing",
      title: "Outer Safety Housing",
      desc: "Finger-safe outer shell with narrow slots preventing curious children or pets from touching the high-voltage grid."
    },
    {
      id: "tray",
      title: "Removable Catch Tray",
      desc: "Twist-off bottom collector cup allowing mess-free disposal of trapped insects."
    },
    {
      id: "thermal_ring",
      title: "Thermal Lure Element (37°C)",
      desc: "Subtle heating circuit that mimics mammalian body temperature to trick blood-seeking mosquitoes."
    }
  ],

  placementTips: [
    {
      title: "Hang at Chest Height (1.2m – 1.8m)",
      detail: "Matches the natural cruising flight height of seeking mosquitoes for the fastest catch rate."
    },
    {
      title: "Keep Other Lights Dim",
      detail: "Turn off bright overhead ceiling lamps so the 365nm purple UV glow maintains maximum contrast in the insect's eyes."
    },
    {
      title: "Place 3 to 5 Meters Away from You",
      detail: "Set the trap across the room from your bed or patio couch so incoming bugs intercept the lamp before reaching your skin."
    },
    {
      title: "Clean the Tray Weekly",
      detail: "Twist off and empty the collection cup regularly to maintain unimpeded airflow and keep the grid clear."
    }
  ],

  evolutionTimeline: [
    { year: "1930s", title: "Open Incandescent", desc: "First high-voltage bug electrocutors patented with open glowing incandescent wires." },
    { year: "1980s", title: "Fluorescent Blacklight", desc: "Black light fluorescent tubes become the gold standard in commercial restaurant kitchens." },
    { year: "2010s", title: "Silent Suction & Thermal", desc: "Quiet fan vortex suction traps and gentle 37°C thermal lures emerge for bedrooms." },
    { year: "2025+", title: "Smart UV-A LEDs & Solar", desc: "Modern low-power 365nm solid-state LEDs, USB-C portability, and autonomous solar garden traps." }
  ]
};
