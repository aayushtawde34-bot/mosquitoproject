// Main Application Entry: Lifecycle, View Synchronization, UI Binding, and Slide Guide
import { AudioEngine } from './simulation/AudioEngine.js';
import { InsectSimulation } from './simulation/InsectSimulation.js';
import { View2D } from './views/View2D.js';
import { View3D } from './views/View3D.js';
import { PRESENTATION_DATA } from './data/presentationData.js';

class App {
  constructor() {
    this.currentViewMode = '3d'; // '3d' | '2d' | 'split'
    this.audio = new AudioEngine();
    this.sim = new InsectSimulation(this.audio);

    this.view2d = null;
    this.view3d = null;

    this.lastTime = performance.now();
    this.isMuted = true;
    this.isPaused = false;

    this.init();
  }

  init() {
    // 1. Initialize Views
    const container3D = document.getElementById('canvas-3d-container');
    this.view3d = new View3D(container3D, this.sim);

    const canvas2D = document.getElementById('canvas-2d');
    this.resize2DCanvas(canvas2D);
    this.view2d = new View2D(canvas2D, this.sim);

    window.addEventListener('resize', () => {
      this.resize2DCanvas(canvas2D);
      this.view3d.onResize();
    });

    // 2. Bind UI Controls
    this.bindViewTabs();
    this.bindActionButtons();
    this.bindCameraPresets();
    this.bind2DSubControls();
    this.bindDayNightToggle();
    this.bindTrapSelectors();
    this.bindWavelengthSelectors();
    this.bindSliders();
    this.bindPresetScenarios();
    this.bindSlideGuideModal();

    // 3. Listen to simulation events for UI feedback
    this.sim.addListener((eventType, data) => {
      if (eventType === 'zap' || eventType === 'suctionCapture' || eventType === 'stickyCapture') {
        this.updateTelemetry();
      }
    });

    // 4. Start Animation Loop
    requestAnimationFrame((t) => this.renderLoop(t));
  }

  resize2DCanvas(canvas) {
    const pane = document.getElementById('pane-2d');
    if (pane) {
      canvas.width = pane.clientWidth || 800;
      canvas.height = pane.clientHeight || 600;
    }
  }

  // Unified Animation Loop
  renderLoop(timeNow) {
    const dt = Math.min(0.05, (timeNow - this.lastTime) / 1000);
    this.lastTime = timeNow;

    if (!this.isPaused) {
      this.sim.update(dt);
    }

    // Render active views
    if (this.currentViewMode === '3d' || this.currentViewMode === 'split') {
      this.view3d.update(dt, timeNow);
    }
    if (this.currentViewMode === '2d' || this.currentViewMode === 'split') {
      this.view2d.render(timeNow);
    }

    // Periodic telemetry update (every ~10 frames)
    if (Math.floor(timeNow / 16) % 8 === 0) {
      this.updateTelemetry();
    }

    requestAnimationFrame((t) => this.renderLoop(t));
  }

  // View Mode Switching (3D / 2D / Split)
  bindViewTabs() {
    const tabs = document.querySelectorAll('.view-mode-tabs .tab-btn');
    const wrapper = document.getElementById('viewports-wrapper');
    const pane3D = document.getElementById('pane-3d');
    const pane2D = document.getElementById('pane-2d');

    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        tab.classList.add('active');

        const mode = tab.dataset.view;
        this.currentViewMode = mode;

        if (mode === '3d') {
          wrapper.classList.remove('split-mode');
          pane3D.className = 'viewport-pane active-full';
          pane2D.className = 'viewport-pane hidden';
          this.view3d.onResize();
        } else if (mode === '2d') {
          wrapper.classList.remove('split-mode');
          pane3D.className = 'viewport-pane hidden';
          pane2D.className = 'viewport-pane active-full';
          this.resize2DCanvas(document.getElementById('canvas-2d'));
        } else if (mode === 'split') {
          wrapper.classList.add('split-mode');
          pane3D.className = 'viewport-pane';
          pane2D.className = 'viewport-pane';
          setTimeout(() => {
            this.view3d.onResize();
            this.resize2DCanvas(document.getElementById('canvas-2d'));
          }, 50);
        }
      });
    });
  }

  bindActionButtons() {
    // Audio Toggle
    const btnAudio = document.getElementById('btn-audio-toggle');
    const iconSoundOff = document.getElementById('icon-sound-off');
    const iconSoundOn = document.getElementById('icon-sound-on');

    btnAudio.addEventListener('click', () => {
      this.isMuted = !this.isMuted;
      this.audio.setMuted(this.isMuted);
      btnAudio.classList.toggle('active', !this.isMuted);
      iconSoundOff.style.display = this.isMuted ? 'block' : 'none';
      iconSoundOn.style.display = this.isMuted ? 'none' : 'block';
    });

    // Play / Pause
    const btnPlayPause = document.getElementById('btn-play-pause');
    const iconPause = document.getElementById('icon-pause');
    const iconPlay = document.getElementById('icon-play');

    btnPlayPause.addEventListener('click', () => {
      this.isPaused = !this.isPaused;
      this.sim.isPaused = this.isPaused;
      iconPause.style.display = this.isPaused ? 'none' : 'block';
      iconPlay.style.display = this.isPaused ? 'block' : 'none';
    });

    // Spawn Swarm
    document.getElementById('btn-spawn-burst').addEventListener('click', () => {
      this.sim.spawnSwarm(15);
      this.updateTelemetry();
    });

    // Empty Tray
    document.getElementById('btn-clean-tray').addEventListener('click', () => {
      this.sim.clearCatchTray();
      this.updateTelemetry();
    });
  }

  bindCameraPresets() {
    const camButtons = document.querySelectorAll('.camera-pill-btn');
    camButtons.forEach(btn => {
      btn.addEventListener('click', () => {
        camButtons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        this.view3d.setCameraPreset(btn.dataset.cam);
      });
    });
  }

  bind2DSubControls() {
    const btnTopdown = document.getElementById('btn-2d-topdown');
    const btnSide = document.getElementById('btn-2d-side');
    const btnRuler = document.getElementById('btn-2d-ruler');

    btnTopdown.addEventListener('click', () => {
      btnTopdown.classList.add('active');
      btnSide.classList.remove('active');
      this.view2d.setMode('topdown');
    });

    btnSide.addEventListener('click', () => {
      btnSide.classList.add('active');
      btnTopdown.classList.remove('active');
      this.view2d.setMode('side');
    });

    btnRuler.addEventListener('click', () => {
      this.view2d.showRuler = !this.view2d.showRuler;
      btnRuler.textContent = `Ruler: ${this.view2d.showRuler ? 'ON' : 'OFF'}`;
      btnRuler.classList.toggle('active', this.view2d.showRuler);
    });
  }

  bindTrapSelectors() {
    const cards = document.querySelectorAll('.trap-card');
    cards.forEach(card => {
      card.addEventListener('click', () => {
        cards.forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        const type = card.dataset.trap;
        this.sim.setTrapType(type);
        this.updateTelemetry();
      });
    });
  }

  bindWavelengthSelectors() {
    const buttons = document.querySelectorAll('.wavelength-btn');
    const rateText = document.getElementById('attraction-rate-text');

    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        buttons.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const nm = Number(btn.dataset.nm);
        this.sim.setWavelength(nm);

        const data = this.sim.getWavelengthData();
        rateText.textContent = `${data.attraction}% Attraction (${data.label})`;
        rateText.style.color = data.color;
      });
    });
  }

  bindSliders() {
    // Ambient Light Slider
    const sliderLight = document.getElementById('slider-ambient-light');
    const valLight = document.getElementById('val-ambient-light');
    sliderLight.addEventListener('input', (e) => {
      const v = Number(e.target.value);
      this.sim.setAmbientLight(v);
      const pct = Math.round(v * 100);
      valLight.textContent = pct < 20 ? `Dark Night (${pct}%)` : pct < 60 ? `Dim Interior (${pct}%)` : `Bright Daylight (${pct}%)`;
    });

    // Lamp Height Slider
    const sliderHeight = document.getElementById('slider-lamp-height');
    const valHeight = document.getElementById('val-lamp-height');
    sliderHeight.addEventListener('input', (e) => {
      const h = Number(e.target.value);
      this.sim.setLampHeight(h);
      const isOptimal = h >= 1.2 && h <= 1.8;
      valHeight.textContent = `${h.toFixed(1)} m ${isOptimal ? '(Optimal Chest)' : '(Non-standard)'}`;
      valHeight.style.color = isOptimal ? 'var(--cyan-accent)' : 'var(--amber)';
    });

    // Human Spacing Slider
    const sliderHuman = document.getElementById('slider-human-distance');
    const valHuman = document.getElementById('val-human-distance');
    sliderHuman.addEventListener('input', (e) => {
      const d = Number(e.target.value);
      this.sim.setHumanDistance(d);
      const isOptimal = d >= 3.0 && d <= 5.0;
      valHuman.textContent = `${d.toFixed(1)} m ${isOptimal ? '(Optimal 3-5m)' : d < 3.0 ? '⚠ Too Close (<3m)' : 'Far (>5m)'}`;
      valHuman.style.color = isOptimal ? 'var(--emerald)' : 'var(--amber)';
    });
  }

  bindDayNightToggle() {
    const btnNight = document.getElementById('btn-night-mode');
    const btnDay = document.getElementById('btn-day-mode');
    if (!btnNight || !btnDay) return;

    btnNight.addEventListener('click', () => {
      btnNight.classList.add('active');
      btnDay.classList.remove('active');
      this.setDayNightMode(false);
    });

    btnDay.addEventListener('click', () => {
      btnDay.classList.add('active');
      btnNight.classList.remove('active');
      this.setDayNightMode(true);
    });
  }

  setDayNightMode(isDay) {
    this.sim.setDayNightMode(isDay);
    if (this.view3d) this.view3d.setDayNightMode(isDay);
    if (this.view2d) this.view2d.setDayNightMode(isDay);

    const btnNight = document.getElementById('btn-night-mode');
    const btnDay = document.getElementById('btn-day-mode');
    if (btnNight && btnDay) {
      btnNight.classList.toggle('active', !isDay);
      btnDay.classList.toggle('active', isDay);
    }

    const sliderLight = document.getElementById('slider-ambient-light');
    const valLight = document.getElementById('val-ambient-light');
    const val = isDay ? 0.85 : 0.12;
    if (sliderLight) sliderLight.value = val;
    if (valLight) {
      valLight.textContent = isDay ? 'Bright Daylight (85%)' : 'Dark Night (12%)';
      valLight.style.color = isDay ? 'var(--amber)' : 'var(--cyan-accent)';
    }
  }

  bindPresetScenarios() {
    const cards = document.querySelectorAll('.preset-card');
    cards.forEach(card => {
      card.addEventListener('click', () => {
        cards.forEach(c => c.classList.remove('active'));
        card.classList.add('active');
        this.applyScenario(card.dataset.preset);
      });
    });
  }

  applyScenario(preset) {
    if (preset === 'bedroom') {
      // Bedroom Sleep: Suction fan, 365nm UV, Night Mode, 3.8m spacing
      this.setDayNightMode(false);
      this.setTrapUI('suction');
      this.setWavelengthUI(365);
      this.setHumanDistanceUI(3.8);
      this.setLampHeightUI(1.4);
    } else if (preset === 'patio') {
      // Patio Zapper: High voltage grid, 365nm UV, Night Mode, 3.2m spacing
      this.setDayNightMode(false);
      this.setTrapUI('zapper');
      this.setWavelengthUI(365);
      this.setHumanDistanceUI(3.2);
      this.setLampHeightUI(1.6);
    } else if (preset === 'daylight') {
      // Day Mode Test: Bright sunlight washes UV contrast (Slide 11)
      this.setDayNightMode(true);
      this.setTrapUI('solar');
      this.setWavelengthUI(365);
      this.setHumanDistanceUI(3.0);
      this.setLampHeightUI(1.5);
    } else if (preset === 'scientific') {
      // Scientific test: 550nm green light (poor attraction) to demonstrate contrast
      this.setDayNightMode(false);
      this.setTrapUI('zapper');
      this.setWavelengthUI(550);
      this.setHumanDistanceUI(3.5);
    }
  }

  setTrapUI(type) {
    this.sim.setTrapType(type);
    document.querySelectorAll('.trap-card').forEach(c => {
      c.classList.toggle('active', c.dataset.trap === type);
    });
  }

  setWavelengthUI(nm) {
    this.sim.setWavelength(nm);
    document.querySelectorAll('.wavelength-btn').forEach(b => {
      b.classList.toggle('active', Number(b.dataset.nm) === nm);
    });
    const data = this.sim.getWavelengthData();
    const rateText = document.getElementById('attraction-rate-text');
    rateText.textContent = `${data.attraction}% Attraction (${data.label})`;
    rateText.style.color = data.color;
  }

  setAmbientUI(val) {
    this.sim.setAmbientLight(val);
    document.getElementById('slider-ambient-light').value = val;
    const pct = Math.round(val * 100);
    document.getElementById('val-ambient-light').textContent = `${pct}% Ambient`;
  }

  setHumanDistanceUI(d) {
    this.sim.setHumanDistance(d);
    document.getElementById('slider-human-distance').value = d;
    document.getElementById('val-human-distance').textContent = `${d.toFixed(1)} m`;
  }

  setLampHeightUI(h) {
    this.sim.setLampHeight(h);
    document.getElementById('slider-lamp-height').value = h;
    document.getElementById('val-lamp-height').textContent = `${h.toFixed(1)} m`;
  }

  updateTelemetry() {
    const m = this.sim.getMetrics();

    // KPIs
    document.getElementById('kpi-trapped-count').textContent = m.totalTrapped;
    document.getElementById('kpi-efficiency').textContent = `${m.efficiencyPercent}%`;
    document.getElementById('kpi-bites-prevented').textContent = m.bitesPrevented;
    document.getElementById('kpi-active-insects').textContent = m.activeFlying;
    document.getElementById('trap-sound-db').textContent = `${m.soundDb} dB (${m.trapSound.split(' ')[0]})`;

    // Mosquito Target Dynamics
    const trapped = m.totalTrapped;
    const spawned = m.totalSpawned || 1;

    // 1. Total Neutralized
    const elemCountMosquito = document.getElementById('count-mosquito');
    const elemBarMosquito = document.getElementById('bar-mosquito');
    if (elemCountMosquito) elemCountMosquito.textContent = trapped;
    if (elemBarMosquito) {
      elemBarMosquito.style.width = `${Math.min(100, Math.round((trapped / spawned) * 100))}%`;
    }

    // 2. Bites Intercepted
    const elemCountBites = document.getElementById('count-bites');
    const elemBarBites = document.getElementById('bar-bites');
    if (elemCountBites) elemCountBites.textContent = m.bitesPrevented;
    if (elemBarBites) {
      elemBarBites.style.width = `${Math.min(100, m.bitesPrevented * 4)}%`;
    }

    // 3. 365nm UV Phototaxis Captures
    const uvCaptures = Math.round(trapped * 0.72);
    const elemCountUv = document.getElementById('count-uv');
    const elemBarUv = document.getElementById('bar-uv');
    if (elemCountUv) elemCountUv.textContent = uvCaptures;
    if (elemBarUv) {
      const attraction = this.sim.getWavelengthData().attraction;
      elemBarUv.style.width = `${attraction}%`;
    }

    // 4. 37C Thermal Mimicry Captures
    const thermalCaptures = Math.round(trapped * 0.28);
    const elemCountThermal = document.getElementById('count-thermal');
    const elemBarThermal = document.getElementById('bar-thermal');
    if (elemCountThermal) elemCountThermal.textContent = thermalCaptures;
    if (elemBarThermal) {
      elemBarThermal.style.width = this.sim.lamp.thermalActive ? '85%' : '10%';
    }
  }

  bindSlideGuideModal() {
    const btnOpen = document.getElementById('btn-open-guide');
    const modal = document.getElementById('guide-modal');
    const btnClose = document.getElementById('btn-close-modal');
    const navList = document.getElementById('slide-nav-list');
    const detailPane = document.getElementById('slide-detail-pane');

    const slides = [
      {
        id: 1,
        title: "Overview: Safe Protection",
        badge: "Slide 1 & 2 • Foundation",
        h1: "Chemical-Free Flying Pest Defense",
        desc: "Modern insect lamps provide a healthy, continuous way to catch flying pests without aerosol sprays, toxic coils, or chemical vaporizers. By pairing natural ultraviolet light lure with subtle mammalian warmth (37°C), lamps protect families, dining areas, and patios safely.",
        cards: [
          { title: "Zero Toxic Residue", text: "Leaves no poisonous fumes or airborne chemical traces in living spaces." },
          { title: "No Pest Resistance", text: "Insects cannot develop physiological resistance to ultraviolet light traps." },
          { title: "Continuous Day & Night Guard", text: "Maintains uninterrupted protection around infants, elderly family, and pets." }
        ]
      },
      {
        id: 2,
        title: "How Insect Traps Work",
        badge: "Slide 3 • 3-Stage Mechanism",
        h1: "Light Lure + Warmth + Capture",
        desc: "Every modern insect trap relies on three scientifically calibrated physiological triggers to attract and neutralize flying pests:",
        cards: [
          { title: "1. 365nm UV Light Lure", text: "Emits specific ultraviolet wavelengths tuned to compound insect eyes, creating irresistible phototaxis contrast." },
          { title: "2. 37°C Body Warmth", text: "Built-in thermal elements mimic human body temperature, tricking blood-seeking mosquitoes into flying in." },
          { title: "3. Safe Capture Mechanism", text: "Electrified grid delivers instantaneous shock, or silent vortex fan pulls bugs into an escape-proof catch cup." }
        ]
      },
      {
        id: 3,
        title: "Light Wavelength Spectrum",
        badge: "Slide 5 • Phototaxis Physics",
        h1: "Which Light Colors Bugs Prefer",
        desc: "Compound eyes of nocturnal flying pests are biologically tuned to ultraviolet light. Wavelength selection directly governs attraction efficiency:",
        cards: [
          { title: "365 nm (Deep UV-A): 94%", text: "Highest phototactic attraction. Attracts over 5x more flying bugs than standard household room lighting." },
          { title: "395 nm (Near-UV): 71%", text: "High attraction spectrum, commonly utilized in energy-saving LED strips." },
          { title: "450 nm (Blue): 43%", text: "Moderate attraction, visible blue range." },
          { title: "550 nm (Green): 18%", text: "Low phototactic response for nocturnal biting mosquitoes; poor lure." }
        ]
      },
      {
        id: 4,
        title: "Key Lamp Anatomy",
        badge: "Slide 6 • Hardware Engineering",
        h1: "Anatomy of an Insect Killer",
        desc: "Explore the critical components engineered inside modern zappers and suction traps:",
        cards: [
          { title: "UV Light Core", text: "Energy-efficient 365nm quartz tubes or LED matrix tuned for maximum bug eye sensitivity." },
          { title: "Electrified Wire Grid", text: "Galvanized wire cage charged with 1500V–3000V to stop insects instantly upon touch." },
          { title: "Outer Safety Housing", text: "Finger-safe slotted outer shell preventing curious pets or children from touching high-voltage coils." },
          { title: "Removable Catch Tray", text: "Twist-off bottom collector cup allowing mess-free disposal of trapped pests." }
        ]
      },
      {
        id: 5,
        title: "Trap Mechanism Comparison",
        badge: "Slide 4 & 7 • Comparison Matrix",
        h1: "Comparing Trap Types",
        desc: "Choosing the optimal trap depends on sound tolerance, power requirements, and room environment:",
        cards: [
          { title: "High-Voltage Zapper", text: "15W–40W • Audible Zap (>65 dB) • Best for outdoor patios, balconies, garages, and large open rooms." },
          { title: "Quiet Vortex Suction Fan", text: "5W–12W • Whisper Quiet (<25 dB) • Downward air vortex pulls bugs whole; ideal for bedrooms & nurseries." },
          { title: "Hygienic Sticky Pad", text: "8W–20W • 100% Silent (0 dB) • Non-drying glue pad; food-grade for kitchens, cafes, and pantries." },
          { title: "Solar Outdoor Lamp", text: "3W–10W • Soft Zap (~50 dB) • Battery + electro-mesh with daylight charging for off-grid gardens." }
        ]
      },
      {
        id: 6,
        title: "Insect Species Breakdown",
        badge: "Slide 8 • Biological Distribution",
        h1: "What Bugs Are Trapped?",
        desc: "Field capture studies confirm that biting mosquitoes and household pests make up 88% of all trapped insects:",
        cards: [
          { title: "Mosquitoes & Midges: 42%", text: "Attracted by 37°C body heat + 365nm UV; eradicated before biting." },
          { title: "Fruit Flies & Drain Gnats: 28%", text: "Fast darting swarms drawn to light contrast gradients." },
          { title: "Houseflies & Blowflies: 18%", text: "High momentum zig-zag flyers intercepted by electric grid or fan vortex." },
          { title: "Night Moths & Beetles: 12%", text: "Transverse phototaxis orientation causes classic inward spiral flight." }
        ]
      },
      {
        id: 7,
        title: "Best Placement Tips",
        badge: "Slide 11 • Optimal Performance",
        h1: "Maximizing Trap Catch Rates",
        desc: "Follow these 4 scientific rules to achieve peak catch efficiency in any home or patio:",
        cards: [
          { title: "Hang at Chest Height (1.2m – 1.8m)", text: "Matches the natural cruising flight altitude of mosquitoes for the quickest catch." },
          { title: "Keep Other Lights Dim", text: "Turn off bright overhead room lamps so bugs easily spot the high-contrast 365nm purple glow." },
          { title: "Place 3 to 5 Meters Away from You", text: "Position the trap across the room from your bed or couch so pests intercept the lamp before reaching your skin." },
          { title: "Clean the Tray Weekly", text: "Twist off and empty the collection cup regularly to keep airflow strong and the unit clean." }
        ]
      },
      {
        id: 8,
        title: "Historical Evolution",
        badge: "Slide 10 • Technology Timeline",
        h1: "Evolution of Insect Lamps",
        desc: "From early open incandescent wires to smart solid-state UV LEDs:",
        cards: [
          { title: "1930s: Open High-Voltage", text: "First high-voltage bug electrocutors patented with open incandescent wires." },
          { title: "1980s: Fluorescent Black Light", text: "Black light fluorescent tubes become standard in commercial food preparation." },
          { title: "2010s: Quiet Suction & Thermal", text: "Whisper-quiet fan vortex traps and 37°C thermal lures emerge for bedrooms." },
          { title: "2025+: Smart UV LEDs & Solar", text: "Ultra low-power 365nm solid-state LEDs, USB-C portability, and autonomous solar garden traps." }
        ]
      }
    ];

    // Populate Slide Nav
    navList.innerHTML = '';
    slides.forEach((sl, idx) => {
      const item = document.createElement('div');
      item.className = `slide-nav-item ${idx === 0 ? 'active' : ''}`;
      item.textContent = `${idx + 1}. ${sl.title}`;
      item.addEventListener('click', () => {
        document.querySelectorAll('.slide-nav-item').forEach(n => n.classList.remove('active'));
        item.classList.add('active');
        this.renderSlideContent(sl, detailPane);
      });
      navList.appendChild(item);
    });

    this.renderSlideContent(slides[0], detailPane);

    // Modal Events
    btnOpen.addEventListener('click', () => modal.classList.add('active'));
    btnClose.addEventListener('click', () => modal.classList.remove('active'));
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.remove('active');
    });
  }

  renderSlideContent(sl, pane) {
    pane.innerHTML = `
      <div class="slide-badge">${sl.badge}</div>
      <h1 class="slide-h1">${sl.h1}</h1>
      <p class="slide-desc">${sl.desc}</p>
      <div class="slide-cards-grid">
        ${sl.cards.map(c => `
          <div class="slide-card-box">
            <div class="slide-card-title">${c.title}</div>
            <div class="slide-card-text">${c.text}</div>
          </div>
        `).join('')}
      </div>
    `;
  }
}

// Instantiate on DOM load
window.addEventListener('DOMContentLoaded', () => {
  window.simApp = new App();
});
