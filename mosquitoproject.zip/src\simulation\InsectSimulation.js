// Insect Simulation Engine: Physics, Phototaxis, Thermotaxis, Vortex Suction, and High-Voltage Discharges
import { PRESENTATION_DATA } from '../data/presentationData.js';

export class InsectSimulation {
  constructor(audioEngine) {
    this.audio = audioEngine;

    // Room boundaries (in meters)
    this.room = {
      width: 5.6,   // X: -2.8 to 2.8
      length: 4.6,  // Z: -2.3 to 2.3
      height: 2.8   // Y: 0 to 2.8 (floor to ceiling)
    };

    // Lamp State
    this.lamp = {
      x: 0,
      y: 1.5, // 1.5m chest height (Slide 11 recommendation)
      z: 0,
      radius: 0.22,
      gridRadius: 0.25,
      suctionRadius: 0.75,
      trapType: 'zapper', // 'zapper' | 'suction' | 'sticky' | 'solar'
      wavelength: 365,   // 365 | 395 | 450 | 550 nm
      powerWatts: 20,
      voltage: 2400,     // Volts for zapper
      fanRpm: 2200,      // RPM for suction fan
      thermalActive: true,
      thermalTemp: 37,   // degrees C
      isOn: true
    };

    // Competing Human Host (Slide 3 & 11)
    this.human = {
      active: true,
      x: 1.8,
      y: 0.9,
      z: 1.2,
      bodyTemp: 37.0, // degrees C
      breathCO2: 1.0,
      bitesCount: 0
    };

    // Environment Factors
    this.isDayMode = false;
    this.ambientLight = 0.12; // 0.0 (pitch dark) to 1.0 (bright daytime / ceiling light)
    this.timeScale = 1.0;
    this.isPaused = false;

    // Insects Array
    this.insects = [];
    this.maxInsects = 80;
    this.targetInsects = 45;

    // Active Spark & Discharge Visuals
    this.activeDischarges = []; // { id, start: {x,y,z}, end: {x,y,z}, life: 0..1, sparks: [] }

    // Statistics Tracker
    this.stats = {
      totalSpawned: 0,
      totalTrapped: 0,
      trappedBySpecies: {
        mosquito: 0,
        fruitfly: 0,
        housefly: 0,
        moth: 0
      },
      bitesPrevented: 0,
      humanBites: 0,
      recentEvents: [],
      lastZapTime: 0
    };

    // Listeners for UI updates
    this.listeners = [];

    // Initialize initial insect population
    this.resetSwarm();
  }

  addListener(fn) {
    this.listeners.push(fn);
  }

  notifyListeners(eventType, data) {
    for (const fn of this.listeners) {
      fn(eventType, data);
    }
  }

  getWavelengthData() {
    return PRESENTATION_DATA.wavelengths.find(w => w.nm === this.lamp.wavelength) || PRESENTATION_DATA.wavelengths[0];
  }

  getTrapData() {
    return PRESENTATION_DATA.trapTypes[this.lamp.trapType] || PRESENTATION_DATA.trapTypes.zapper;
  }

  setTrapType(type) {
    if (PRESENTATION_DATA.trapTypes[type]) {
      this.lamp.trapType = type;
      if (this.audio) {
        this.audio.setFanActive(type === 'suction', 0.4);
      }
      this.notifyListeners('trapTypeChanged', type);
    }
  }

  setWavelength(nm) {
    this.lamp.wavelength = Number(nm);
    this.notifyListeners('wavelengthChanged', nm);
  }

  setAmbientLight(val) {
    this.ambientLight = Math.max(0, Math.min(1, Number(val)));
  }

  setDayNightMode(isDay) {
    this.isDayMode = isDay;
    this.ambientLight = isDay ? 0.85 : 0.12;
    this.notifyListeners('dayNightChanged', isDay);
  }

  setLampHeight(y) {
    this.lamp.y = Math.max(0.6, Math.min(2.4, Number(y)));
  }

  setHumanDistance(dist) {
    // Places human at angle relative to lamp
    const angle = 0.55;
    this.human.x = this.lamp.x + Math.cos(angle) * dist;
    this.human.z = this.lamp.z + Math.sin(angle) * dist;
  }

  getHumanDistance() {
    const dx = this.human.x - this.lamp.x;
    const dz = this.human.z - this.lamp.z;
    return Math.sqrt(dx * dx + dz * dz);
  }

  resetSwarm(count = this.targetInsects) {
    this.insects = [];
    this.activeDischarges = [];
    this.spawnSwarm(count);
  }

  clearCatchTray() {
    // Empties accumulated catches in catch cup (Slide 11 clean tray)
    this.stats.totalTrapped = 0;
    this.stats.trappedBySpecies = { mosquito: 0, fruitfly: 0, housefly: 0, moth: 0 };
    this.insects = this.insects.filter(bug => bug.state === 'flying');
    this.notifyListeners('trayCleaned', null);
  }

  spawnSwarm(count) {
    for (let i = 0; i < count; i++) {
      this.spawnInsect();
    }
  }

  spawnInsect(preferredSpecies = null) {
    // 100% Mosquito simulation as requested
    const speciesId = 'mosquito';
    const speciesDef = PRESENTATION_DATA.insectSpecies.find(s => s.id === 'mosquito') || {
      id: 'mosquito',
      name: 'Mosquitoes (Culicidae)',
      speed: 1.35,
      size: 1.0,
      thermalAffinity: 0.95,
      lightAffinity: 0.92,
      erraticness: 0.8
    };

    // Spawn randomly around edges of room (cracks, window, ceiling)
    const edge = Math.floor(Math.random() * 4);
    let x = 0, y = 0.4 + Math.random() * 2.2, z = 0;
    const halfW = this.room.width / 2 - 0.2;
    const halfL = this.room.length / 2 - 0.2;

    if (edge === 0) { x = -halfW; z = (Math.random() * 2 - 1) * halfL; }
    else if (edge === 1) { x = halfW; z = (Math.random() * 2 - 1) * halfL; }
    else if (edge === 2) { x = (Math.random() * 2 - 1) * halfW; z = -halfL; }
    else { x = (Math.random() * 2 - 1) * halfW; z = halfL; }

    const speed = speciesDef.speed * (0.8 + Math.random() * 0.4);
    const angle = Math.random() * Math.PI * 2;

    const bug = {
      id: Math.random().toString(36).substr(2, 9),
      species: speciesId,
      speciesDef: speciesDef,
      x: x,
      y: y,
      z: z,
      vx: Math.cos(angle) * speed * 0.3,
      vy: (Math.random() - 0.5) * 0.2,
      vz: Math.sin(angle) * speed * 0.3,
      baseSpeed: speed,
      wingPhase: Math.random() * Math.PI * 2,
      wingSpeed: speciesId === 'mosquito' ? 36 : speciesId === 'fruitfly' ? 45 : speciesId === 'housefly' ? 30 : 18,
      state: 'flying', // 'flying' | 'zapped' | 'falling' | 'trapped'
      stateTimer: 0,
      spiralAngle: Math.random() * Math.PI * 2,
      spiralRadius: 2.0,
      biteAttemptCooloff: 0,
      mass: speciesId === 'mosquito' ? 0.3 : speciesId === 'fruitfly' ? 0.2 : speciesId === 'housefly' ? 0.8 : 1.2
    };

    this.insects.push(bug);
    this.stats.totalSpawned++;
    return bug;
  }

  update(dt) {
    if (this.isPaused) return;

    const scaledDt = Math.min(0.05, dt * this.timeScale);

    // Ensure 100% mosquito swarm
    this.insects = this.insects.filter(b => b.species === 'mosquito');

    // Maintain target population
    const activeFlying = this.insects.filter(b => b.state === 'flying').length;
    if (activeFlying < this.targetInsects && Math.random() < 0.08) {
      this.spawnInsect();
    }

    // Update active lightning discharges and spark bursts
    this.updateDischarges(scaledDt);

    const wavelengthData = this.getWavelengthData();
    const trapData = this.getTrapData();

    // Wavelength attraction efficiency: 94% for 365nm, 71% for 395nm, 43% for 450nm, 18% for 550nm
    const wavelengthFactor = wavelengthData.attraction / 100;

    // Ambient light washes out UV contrast (Slide 11: keep other lights dim)
    // When ambientLight is 0, contrast is 1.0; when ambient is 1.0 (bright), contrast drops to ~0.15
    const lightContrast = Math.max(0.08, 1.0 - this.ambientLight * 0.85);
    const effectiveLampPull = wavelengthFactor * lightContrast * (this.lamp.isOn ? 1.0 : 0.05);

    let closestDistToLamp = 999;

    for (let i = 0; i < this.insects.length; i++) {
      const bug = this.insects[i];

      if (bug.state === 'trapped') {
        continue;
      }

      if (bug.state === 'falling') {
        // Falling dead into catch tray or floor
        bug.vy -= 9.8 * scaledDt * 0.5;
        bug.x += bug.vx * scaledDt * 0.3;
        bug.y += bug.vy * scaledDt;
        bug.z += bug.vz * scaledDt * 0.3;

        // Check if landed in tray or floor
        const trayTop = this.lamp.y - 0.35;
        const distToLampCenter = Math.hypot(bug.x - this.lamp.x, bug.z - this.lamp.z);

        if (distToLampCenter < this.lamp.radius * 1.3 && Math.abs(bug.y - trayTop) < 0.08) {
          bug.y = trayTop;
          bug.vy = 0;
          bug.state = 'trapped';
        } else if (bug.y <= 0.05) {
          bug.y = 0.05;
          bug.vy = 0;
          bug.state = 'trapped';
        }
        continue;
      }

      if (bug.state === 'zapped') {
        bug.stateTimer -= scaledDt;
        if (bug.stateTimer <= 0) {
          bug.state = 'falling';
          bug.vy = -0.5;
        }
        continue;
      }

      // FLYING STATE:
      bug.wingPhase += bug.wingSpeed * scaledDt * 10;
      if (bug.biteAttemptCooloff > 0) bug.biteAttemptCooloff -= scaledDt;

      // Vectors to Lamp and Human
      const dxLamp = this.lamp.x - bug.x;
      const dyLamp = this.lamp.y - bug.y;
      const dzLamp = this.lamp.z - bug.z;
      const distLamp = Math.sqrt(dxLamp * dxLamp + dyLamp * dyLamp + dzLamp * dzLamp) || 0.01;

      if (distLamp < closestDistToLamp) closestDistToLamp = distLamp;

      let dxHuman = 0, dyHuman = 0, dzHuman = 0, distHuman = 999;
      if (this.human.active) {
        dxHuman = this.human.x - bug.x;
        dyHuman = this.human.y - bug.y;
        dzHuman = this.human.z - bug.z;
        distHuman = Math.sqrt(dxHuman * dxHuman + dyHuman * dyHuman + dzHuman * dzHuman) || 0.01;
      }

      // Physics Steering Forces:
      let fx = 0, fy = 0, fz = 0;

      // 1. Phototaxis Force toward UV Lamp
      // Inverse-square law with saturation falloff
      const phototaxisStrength = (effectiveLampPull * bug.speciesDef.lightAffinity * 2.8) / (distLamp * 0.6 + 0.4);

      // Transverse Phototaxis (specifically Moths fly in logarithmic spiral)
      if (bug.species === 'moth' && distLamp < 3.0) {
        // Moths maintain an ~80 degree transverse angle relative to light ray
        const dirX = dxLamp / distLamp;
        const dirZ = dzLamp / distLamp;
        // Tangent vector
        const tanX = -dirZ;
        const tanZ = dirX;
        // Inward spiral combination (tan + dir)
        fx += (dirX * 0.45 + tanX * 0.85) * phototaxisStrength * 0.7;
        fz += (dirZ * 0.45 + tanZ * 0.85) * phototaxisStrength * 0.7;
        fy += (dyLamp / distLamp) * phototaxisStrength * 0.4;
      } else {
        fx += (dxLamp / distLamp) * phototaxisStrength;
        fy += (dyLamp / distLamp) * phototaxisStrength * 0.7;
        fz += (dzLamp / distLamp) * phototaxisStrength;
      }

      // 2. Thermotaxis & CO2 Plume (Human vs Lamp Thermal Ring)
      // Lamp 37C thermal ring mimics human body warmth (Slide 3)
      if (this.lamp.thermalActive && distLamp < 2.5) {
        const thermalPull = (bug.speciesDef.thermalAffinity * 1.2) / (distLamp + 0.3);
        fx += (dxLamp / distLamp) * thermalPull;
        fy += (dyLamp / distLamp) * thermalPull;
        fz += (dzLamp / distLamp) * thermalPull;
      }

      // Competing Human Host attraction
      if (this.human.active) {
        // Mosquitoes are heavily attracted to human body heat & breathing
        const humanAttraction = (bug.speciesDef.thermalAffinity * 1.8) / (distHuman * 0.7 + 0.5);

        // If bug is much closer to human than lamp, human heat wins unless lamp 365nm UV lure dominates
        if (distHuman < distLamp * 0.7 || effectiveLampPull < 0.4) {
          fx += (dxHuman / distHuman) * humanAttraction;
          fy += (dyHuman / distHuman) * humanAttraction * 0.5;
          fz += (dzHuman / distHuman) * humanAttraction;
        }

        // Bite check: if bug reaches human (<0.28m)
        if (distHuman < 0.28 && bug.biteAttemptCooloff <= 0) {
          this.stats.humanBites++;
          bug.biteAttemptCooloff = 4.0; // flies away after bite
          // Scatter away
          fx -= (dxHuman / distHuman) * 3.0;
          fz -= (dzHuman / distHuman) * 3.0;
          this.notifyListeners('humanBite', { species: bug.species });
        }
      }

      // 3. Erratic biological Brownian motion & flight cruising
      const erratic = bug.speciesDef.erraticness;
      fx += (Math.random() - 0.5) * erratic * 2.2;
      fy += (Math.random() - 0.5) * erratic * 1.6;
      fz += (Math.random() - 0.5) * erratic * 2.2;

      // Authentic Mosquito Hovering & Bobbing Kinematics
      if (bug.species === 'mosquito') {
        // Mosquitoes bob vertically in flight with a 4-6 Hz hovering oscillation
        fy += Math.sin(bug.wingPhase * 0.18) * 1.6;
        // Periodic hovering hesitation (pause and sniff CO2/warmth)
        if (Math.sin(bug.wingPhase * 0.05) > 0.7) {
          bug.vx *= 0.88;
          bug.vz *= 0.88;
        }
      }

      // Natural hovering height tendency (Chest height 1.2m - 1.8m, Slide 11)
      const idealHeight = 1.4 + Math.sin(bug.wingPhase * 0.1) * 0.3;
      fy += (idealHeight - bug.y) * 0.4;

      // 4. Trap Specific Capture Zone Mechanics
      const horizDistToLamp = Math.hypot(dxLamp, dzLamp);
      const vertDistToLamp = Math.abs(dyLamp);

      if (this.lamp.trapType === 'zapper' || this.lamp.trapType === 'solar') {
        // High-Voltage Grid Zap Check!
        // Grid cylinder radius ~0.24m, height +/- 0.22m
        if (horizDistToLamp <= this.lamp.gridRadius && vertDistToLamp <= 0.25) {
          this.triggerZap(bug);
          continue;
        }
      } else if (this.lamp.trapType === 'suction') {
        // Vortex Suction Fan (Slide 3 & 4)
        // Downward vortex draft pulls insects into bottom escape-proof tray
        if (distLamp < this.lamp.suctionRadius) {
          const suctionNorm = 1.0 - distLamp / this.lamp.suctionRadius;
          const vortexPower = suctionNorm * suctionNorm * 7.5;

          // Tangential swirl (whirlpool)
          const swirlX = -dzLamp / (horizDistToLamp + 0.05);
          const swirlZ = dxLamp / (horizDistToLamp + 0.05);

          // Strong downward pull toward the fan intake
          fx += (dxLamp * 2.0 + swirlX * 3.0) * vortexPower;
          fy += (-4.5 + dyLamp * 1.5) * vortexPower; // pulls downward!
          fz += (dzLamp * 2.0 + swirlZ * 3.0) * vortexPower;

          // If insect is pulled into fan throat:
          if (horizDistToLamp < 0.16 && vertDistToLamp < 0.22) {
            this.triggerSuctionCapture(bug);
            continue;
          }
        }
      } else if (this.lamp.trapType === 'sticky') {
        // Hygienic Sticky Pad (Slide 4 & 7)
        // Contact with the sticky pad tray beneath UV light
        if (horizDistToLamp <= this.lamp.radius * 0.95 && bug.y <= this.lamp.y - 0.22 && bug.y >= this.lamp.y - 0.34) {
          this.triggerStickyCapture(bug);
          continue;
        }
      }

      // Room boundary containment (repel from walls, ceiling, floor)
      const halfW = this.room.width / 2;
      const halfL = this.room.length / 2;
      const margin = 0.3;

      if (bug.x < -halfW + margin) fx += 4.0;
      if (bug.x > halfW - margin) fx -= 4.0;
      if (bug.z < -halfL + margin) fz += 4.0;
      if (bug.z > halfL - margin) fz -= 4.0;
      if (bug.y < 0.2) fy += 5.0;
      if (bug.y > this.room.height - 0.2) fy -= 4.0;

      // Integrate Acceleration -> Velocity -> Position
      const accelX = fx / bug.mass;
      const accelY = fy / bug.mass;
      const accelZ = fz / bug.mass;

      bug.vx += accelX * scaledDt;
      bug.vy += accelY * scaledDt;
      bug.vz += accelZ * scaledDt;

      // Speed Clamping & Air Drag
      const currentSpeed = Math.sqrt(bug.vx * bug.vx + bug.vy * bug.vy + bug.vz * bug.vz) || 0.01;
      const maxSpeed = bug.baseSpeed * (this.lamp.trapType === 'suction' && distLamp < this.lamp.suctionRadius ? 3.5 : 1.8);
      if (currentSpeed > maxSpeed) {
        const factor = maxSpeed / currentSpeed;
        bug.vx *= factor;
        bug.vy *= factor;
        bug.vz *= factor;
      }

      // Air resistance
      bug.vx *= 0.96;
      bug.vy *= 0.96;
      bug.vz *= 0.96;

      bug.x += bug.vx * scaledDt;
      bug.y += bug.vy * scaledDt;
      bug.z += bug.vz * scaledDt;
    }

    // Audio proximity whine
    if (this.audio) {
      this.audio.updateProximityBuzz(closestDistToLamp, activeFlying);
    }

    // Periodic cleanup of trapped bugs if excessive
    if (this.insects.length > 250) {
      const trapped = this.insects.filter(b => b.state === 'trapped');
      if (trapped.length > 100) {
        this.insects = this.insects.filter((b, idx) => b.state !== 'trapped' || idx % 2 === 0);
      }
    }
  }

  triggerZap(bug) {
    bug.state = 'zapped';
    bug.stateTimer = 0.08;
    this.stats.totalTrapped++;
    this.stats.trappedBySpecies[bug.species]++;
    this.stats.bitesPrevented++;
    this.stats.lastZapTime = performance.now();

    // Procedural Lightning Spark Discharge
    const angle = Math.atan2(bug.z - this.lamp.z, bug.x - this.lamp.x);
    const gridX = this.lamp.x + Math.cos(angle) * (this.lamp.gridRadius * 0.9);
    const gridY = Math.max(this.lamp.y - 0.2, Math.min(this.lamp.y + 0.2, bug.y));
    const gridZ = this.lamp.z + Math.sin(angle) * (this.lamp.gridRadius * 0.9);

    // Generate branching sparks
    const sparks = [];
    const sparkCount = 8 + Math.floor(Math.random() * 8);
    for (let s = 0; s < sparkCount; s++) {
      sparks.push({
        x: bug.x,
        y: bug.y,
        z: bug.z,
        vx: (Math.random() - 0.5) * 3.5,
        vy: (Math.random() * 2 + 0.5),
        vz: (Math.random() - 0.5) * 3.5,
        life: 0.25 + Math.random() * 0.25
      });
    }

    this.activeDischarges.push({
      id: Math.random().toString(),
      startX: gridX,
      startY: gridY,
      startZ: gridZ,
      endX: bug.x,
      endY: bug.y,
      endZ: bug.z,
      life: 0.12,
      sparks: sparks
    });

    if (this.audio) {
      this.audio.playZap(this.lamp.trapType === 'solar' ? 0.6 : 1.0);
    }

    this.notifyListeners('zap', {
      bug: bug,
      pos: { x: bug.x, y: bug.y, z: bug.z }
    });
  }

  triggerSuctionCapture(bug) {
    bug.state = 'trapped';
    bug.x = this.lamp.x + (Math.random() - 0.5) * 0.15;
    bug.y = this.lamp.y - 0.32;
    bug.z = this.lamp.z + (Math.random() - 0.5) * 0.15;
    bug.vx = 0;
    bug.vy = 0;
    bug.vz = 0;

    this.stats.totalTrapped++;
    this.stats.trappedBySpecies[bug.species]++;
    this.stats.bitesPrevented++;

    if (this.audio) {
      this.audio.playSuctionCapture();
    }

    this.notifyListeners('suctionCapture', { bug });
  }

  triggerStickyCapture(bug) {
    bug.state = 'trapped';
    bug.y = this.lamp.y - 0.30;
    bug.vx = 0;
    bug.vy = 0;
    bug.vz = 0;

    this.stats.totalTrapped++;
    this.stats.trappedBySpecies[bug.species]++;
    this.stats.bitesPrevented++;

    if (this.audio) {
      this.audio.playGlueCapture();
    }

    this.notifyListeners('stickyCapture', { bug });
  }

  updateDischarges(dt) {
    for (let i = this.activeDischarges.length - 1; i >= 0; i--) {
      const disc = this.activeDischarges[i];
      disc.life -= dt;

      // Update particle sparks
      for (const sp of disc.sparks) {
        sp.x += sp.vx * dt;
        sp.y += sp.vy * dt;
        sp.z += sp.vz * dt;
        sp.vy -= 9.8 * dt; // gravity
        sp.life -= dt;
      }

      if (disc.life <= 0 && disc.sparks.every(s => s.life <= 0)) {
        this.activeDischarges.splice(i, 1);
      }
    }
  }

  getMetrics() {
    const active = this.insects.filter(b => b.state === 'flying').length;
    const total = this.stats.totalSpawned;
    const trapped = this.stats.totalTrapped;
    const efficiency = total > 0 ? Math.round((trapped / total) * 100) : 0;
    const trapData = this.getTrapData();

    return {
      activeFlying: active,
      totalTrapped: trapped,
      totalSpawned: total,
      efficiencyPercent: efficiency,
      bitesPrevented: this.stats.bitesPrevented,
      humanBites: this.stats.humanBites,
      speciesBreakdown: { ...this.stats.trappedBySpecies },
      trapName: trapData.name,
      trapPower: trapData.power,
      trapSound: trapData.sound,
      soundDb: trapData.soundValue,
      humanDistance: this.getHumanDistance().toFixed(1)
    };
  }
}
