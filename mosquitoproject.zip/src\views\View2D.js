// High-Performance 2D Tactical & Scientific Visualizer (Top-Down & Cross-Section Views)
export class View2D {
  constructor(canvas, simulation) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d');
    this.sim = simulation;

    // View mode: 'topdown' (X-Z plane) or 'side' (X-Y plane)
    this.mode = 'topdown';
    this.isDayMode = false;

    // Visual layers
    this.showVectorField = true;
    this.showThermalHeatmap = true;
    this.showVortexFlow = true;
    this.showInsectTrails = true;
    this.showRuler = true;

    // Mouse interaction for dragging lamp or human
    this.dragTarget = null; // 'lamp' | 'human' | null
    this.isDragging = false;
    this.dragStartPos = { x: 0, y: 0 };

    this.trailHistory = new Map(); // id -> array of recent points

    this.initEventListeners();
  }

  setDayNightMode(isDay) {
    this.isDayMode = isDay;
  }

  setMode(mode) {
    if (mode === 'topdown' || mode === 'side') {
      this.mode = mode;
      this.trailHistory.clear();
    }
  }

  toggleLayer(layer) {
    if (this[layer] !== undefined) {
      this[layer] = !this[layer];
    }
  }

  initEventListeners() {
    this.canvas.addEventListener('mousedown', (e) => this.onPointerDown(e));
    window.addEventListener('mousemove', (e) => this.onPointerMove(e));
    window.addEventListener('mouseup', () => this.onPointerUp());

    // Touch support
    this.canvas.addEventListener('touchstart', (e) => {
      if (e.touches.length > 0) {
        this.onPointerDown(e.touches[0]);
      }
    }, { passive: false });

    window.addEventListener('touchmove', (e) => {
      if (this.isDragging && e.touches.length > 0) {
        this.onPointerMove(e.touches[0]);
        e.preventDefault();
      }
    }, { passive: false });

    window.addEventListener('touchend', () => this.onPointerUp());
  }

  // World coordinates to canvas screen pixels
  worldToScreen(wx, wy, wz) {
    const w = this.canvas.width;
    const h = this.canvas.height;
    const padding = 50;
    const availW = w - padding * 2;
    const availH = h - padding * 2;

    if (this.mode === 'topdown') {
      // Room X (-2.8 to 2.8) -> screen X
      // Room Z (-2.3 to 2.3) -> screen Y
      const scaleX = availW / this.sim.room.width;
      const scaleY = availH / this.sim.room.length;
      const scale = Math.min(scaleX, scaleY);

      const sx = w / 2 + wx * scale;
      const sy = h / 2 + wz * scale;
      return { x: sx, y: sy, scale };
    } else {
      // Room X (-2.8 to 2.8) -> screen X
      // Room Y (0 to 2.8) -> screen Y (inverted)
      const scaleX = availW / this.sim.room.width;
      const scaleY = availH / this.sim.room.height;
      const scale = Math.min(scaleX, scaleY);

      const sx = w / 2 + wx * scale;
      const sy = h - padding - wy * scale;
      return { x: sx, y: sy, scale };
    }
  }

  // Screen pixels to world coordinates
  screenToWorld(sx, sy) {
    const w = this.canvas.width;
    const h = this.canvas.height;
    const padding = 50;
    const availW = w - padding * 2;
    const availH = h - padding * 2;

    if (this.mode === 'topdown') {
      const scale = Math.min(availW / this.sim.room.width, availH / this.sim.room.length);
      const wx = (sx - w / 2) / scale;
      const wz = (sy - h / 2) / scale;
      return { x: wx, y: this.sim.lamp.y, z: wz };
    } else {
      const scale = Math.min(availW / this.sim.room.width, availH / this.sim.room.height);
      const wx = (sx - w / 2) / scale;
      const wy = (h - padding - sy) / scale;
      return { x: wx, y: wy, z: this.sim.lamp.z };
    }
  }

  onPointerDown(e) {
    const rect = this.canvas.getBoundingClientRect();
    const sx = (e.clientX - rect.left) * (this.canvas.width / rect.width);
    const sy = (e.clientY - rect.top) * (this.canvas.height / rect.height);

    const lampScreen = this.worldToScreen(this.sim.lamp.x, this.sim.lamp.y, this.sim.lamp.z);
    const humanScreen = this.worldToScreen(this.sim.human.x, this.sim.human.y, this.sim.human.z);

    const distLamp = Math.hypot(sx - lampScreen.x, sy - lampScreen.y);
    const distHuman = Math.hypot(sx - humanScreen.x, sy - humanScreen.y);

    if (distLamp < 32) {
      this.dragTarget = 'lamp';
      this.isDragging = true;
      this.canvas.style.cursor = 'grabbing';
    } else if (distHuman < 32 && this.sim.human.active) {
      this.dragTarget = 'human';
      this.isDragging = true;
      this.canvas.style.cursor = 'grabbing';
    }
  }

  onPointerMove(e) {
    const rect = this.canvas.getBoundingClientRect();
    const sx = (e.clientX - rect.left) * (this.canvas.width / rect.width);
    const sy = (e.clientY - rect.top) * (this.canvas.height / rect.height);

    if (this.isDragging && this.dragTarget) {
      const worldPos = this.screenToWorld(sx, sy);
      const halfW = this.sim.room.width / 2 - 0.4;
      const halfL = this.sim.room.length / 2 - 0.4;

      if (this.dragTarget === 'lamp') {
        this.sim.lamp.x = Math.max(-halfW, Math.min(halfW, worldPos.x));
        if (this.mode === 'topdown') {
          this.sim.lamp.z = Math.max(-halfL, Math.min(halfL, worldPos.z));
        } else {
          this.sim.lamp.y = Math.max(0.6, Math.min(2.5, worldPos.y));
        }
      } else if (this.dragTarget === 'human') {
        this.sim.human.x = Math.max(-halfW, Math.min(halfW, worldPos.x));
        if (this.mode === 'topdown') {
          this.sim.human.z = Math.max(-halfL, Math.min(halfL, worldPos.z));
        } else {
          this.sim.human.y = Math.max(0.4, Math.min(1.8, worldPos.y));
        }
      }
    } else {
      // Hover cursor check
      const lampScreen = this.worldToScreen(this.sim.lamp.x, this.sim.lamp.y, this.sim.lamp.z);
      const humanScreen = this.worldToScreen(this.sim.human.x, this.sim.human.y, this.sim.human.z);
      const distLamp = Math.hypot(sx - lampScreen.x, sy - lampScreen.y);
      const distHuman = Math.hypot(sx - humanScreen.x, sy - humanScreen.y);

      if (distLamp < 30 || (distHuman < 30 && this.sim.human.active)) {
        this.canvas.style.cursor = 'grab';
      } else {
        this.canvas.style.cursor = 'default';
      }
    }
  }

  onPointerUp() {
    this.isDragging = false;
    this.dragTarget = null;
    this.canvas.style.cursor = 'default';
  }

  render(timeNow) {
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;

    // Clear background
    ctx.fillStyle = '#0a0d18';
    ctx.fillRect(0, 0, w, h);

    // 1. Draw Room Boundaries & Coordinate Grid
    this.drawRoomGrid(ctx, w, h);

    // 2. Draw Scientific Fields (UV Intensity & Thermal Convection Heatmap)
    if (this.showThermalHeatmap || this.showVectorField) {
      this.drawFieldGradients(ctx);
    }

    // 3. Draw Suction Airflow Whirlpool / Vortex Streamlines
    if (this.showVortexFlow && this.sim.lamp.trapType === 'suction') {
      this.drawVortexStreamlines(ctx, timeNow);
    }

    // 4. Draw Spacing Distance Ruler between Lamp and Human (Slide 11 guideline)
    if (this.showRuler && this.sim.human.active) {
      this.drawDistanceRuler(ctx);
    }

    // 5. Draw Human Host
    if (this.sim.human.active) {
      this.drawHumanHost(ctx, timeNow);
    }

    // 6. Draw Insect Trails & Insects
    this.drawInsects(ctx, timeNow);

    // 7. Draw Electric Arc Lightning Bolts & Sparks (High-voltage discharge)
    this.drawElectricDischarges(ctx);

    // 8. Draw Lamp Structure & Grid/Fan
    this.drawLamp(ctx, timeNow);

    // 9. Draw HUD Overlay (Legend, view info, catch tray mini-badge)
    this.drawHUD(ctx, w, h);
  }

  drawRoomGrid(ctx, w, h) {
    const p1 = this.worldToScreen(-this.sim.room.width / 2, 0, -this.sim.room.length / 2);
    const p2 = this.worldToScreen(this.sim.room.width / 2, this.sim.room.height, this.sim.room.length / 2);

    const minX = Math.min(p1.x, p2.x);
    const maxX = Math.max(p1.x, p2.x);
    const minY = Math.min(p1.y, p2.y);
    const maxY = Math.max(p1.y, p2.y);

    // Room background floor (Day vs Night)
    if (this.isDayMode) {
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(minX, minY, maxX - minX, maxY - minY);
      // Sunlight ray gradient coming from left window
      const sunGrad = ctx.createLinearGradient(minX, minY, maxX, maxY);
      sunGrad.addColorStop(0, 'rgba(254, 240, 138, 0.16)');
      sunGrad.addColorStop(0.5, 'rgba(254, 240, 138, 0.05)');
      sunGrad.addColorStop(1, 'rgba(254, 240, 138, 0)');
      ctx.fillStyle = sunGrad;
      ctx.fillRect(minX, minY, maxX - minX, maxY - minY);
    } else {
      ctx.fillStyle = '#0e1222';
      ctx.fillRect(minX, minY, maxX - minX, maxY - minY);
    }

    // Soft architectural grid lines (every 1 meter)
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    ctx.beginPath();

    const scale = p1.scale;
    const startX = -Math.floor(this.sim.room.width / 2);
    const endX = Math.floor(this.sim.room.width / 2);

    for (let x = startX; x <= endX; x++) {
      const scr = this.worldToScreen(x, 0, 0);
      ctx.moveTo(scr.x, minY);
      ctx.lineTo(scr.x, maxY);
    }

    if (this.mode === 'topdown') {
      const startZ = -Math.floor(this.sim.room.length / 2);
      const endZ = Math.floor(this.sim.room.length / 2);
      for (let z = startZ; z <= endZ; z++) {
        const scr = this.worldToScreen(0, 0, z);
        ctx.moveTo(minX, scr.y);
        ctx.lineTo(maxX, scr.y);
      }
    } else {
      for (let y = 0; y <= 3; y++) {
        const scr = this.worldToScreen(0, y, 0);
        ctx.moveTo(minX, scr.y);
        ctx.lineTo(maxX, scr.y);
      }
    }
    ctx.stroke();

    // Outer Room Border Wall
    ctx.strokeStyle = 'rgba(99, 102, 241, 0.35)';
    ctx.lineWidth = 2.5;
    ctx.strokeRect(minX, minY, maxX - minX, maxY - minY);
  }

  drawFieldGradients(ctx) {
    const lampPos = this.worldToScreen(this.sim.lamp.x, this.sim.lamp.y, this.sim.lamp.z);
    const wl = this.sim.getWavelengthData();
    const scale = lampPos.scale;

    // 1. UV Phototaxis Glow Field
    if (this.showVectorField && this.sim.lamp.isOn) {
      const lureRadiusPixels = 4.5 * scale;
      const uvGrad = ctx.createRadialGradient(
        lampPos.x, lampPos.y, 8,
        lampPos.x, lampPos.y, lureRadiusPixels
      );

      // Contrast dimmer based on ambient light
      const contrast = Math.max(0.12, 1.0 - this.sim.ambientLight * 0.8);
      const alphaPeak = 0.35 * (wl.attraction / 100) * contrast;

      uvGrad.addColorStop(0, `rgba(180, 100, 255, ${alphaPeak * 1.5})`);
      uvGrad.addColorStop(0.2, `rgba(140, 60, 240, ${alphaPeak * 0.9})`);
      uvGrad.addColorStop(0.6, `rgba(90, 40, 180, ${alphaPeak * 0.3})`);
      uvGrad.addColorStop(1, 'rgba(30, 20, 70, 0)');

      ctx.fillStyle = uvGrad;
      ctx.beginPath();
      ctx.arc(lampPos.x, lampPos.y, lureRadiusPixels, 0, Math.PI * 2);
      ctx.fill();

      // Phototaxis Vector Field Streamlines (Arrows / Rings)
      ctx.strokeStyle = `rgba(180, 130, 255, ${0.18 * contrast})`;
      ctx.lineWidth = 1.2;
      ctx.setLineDash([4, 6]);
      for (let r = 0.6; r <= 3.2; r += 0.65) {
        ctx.beginPath();
        ctx.arc(lampPos.x, lampPos.y, r * scale, 0, Math.PI * 2);
        ctx.stroke();
      }
      ctx.setLineDash([]);
    }

    // 2. Thermal Lure Heatmap (37°C warmth gradient, Slide 3)
    if (this.showThermalHeatmap && this.sim.lamp.thermalActive) {
      const heatRadius = 1.6 * scale;
      const heatGrad = ctx.createRadialGradient(
        lampPos.x, lampPos.y, 4,
        lampPos.x, lampPos.y, heatRadius
      );
      heatGrad.addColorStop(0, 'rgba(255, 110, 40, 0.28)');
      heatGrad.addColorStop(0.5, 'rgba(240, 90, 20, 0.12)');
      heatGrad.addColorStop(1, 'rgba(220, 60, 10, 0)');

      ctx.fillStyle = heatGrad;
      ctx.beginPath();
      ctx.arc(lampPos.x, lampPos.y, heatRadius, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  drawVortexStreamlines(ctx, timeNow) {
    const lampPos = this.worldToScreen(this.sim.lamp.x, this.sim.lamp.y, this.sim.lamp.z);
    const scale = lampPos.scale;
    const suctionR = this.sim.lamp.suctionRadius * scale;

    ctx.save();
    ctx.translate(lampPos.x, lampPos.y);

    const arms = 6;
    const t = (timeNow * 0.003) % (Math.PI * 2);

    for (let a = 0; a < arms; a++) {
      const baseAngle = (a / arms) * Math.PI * 2 + t;
      ctx.strokeStyle = 'rgba(0, 245, 255, 0.45)';
      ctx.lineWidth = 1.6;
      ctx.beginPath();

      // Logarithmic spiral stream towards center
      for (let step = 0; step < 40; step++) {
        const factor = step / 40;
        const r = suctionR * (1 - factor);
        const theta = baseAngle + factor * 2.8;
        const px = Math.cos(theta) * r;
        const py = Math.sin(theta) * r;
        if (step === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      }
      ctx.stroke();
    }

    // Suction boundary dashed circle
    ctx.strokeStyle = 'rgba(0, 245, 255, 0.3)';
    ctx.lineWidth = 1.2;
    ctx.setLineDash([3, 4]);
    ctx.beginPath();
    ctx.arc(0, 0, suctionR, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.restore();
  }

  drawDistanceRuler(ctx) {
    const lampPos = this.worldToScreen(this.sim.lamp.x, this.sim.lamp.y, this.sim.lamp.z);
    const humanPos = this.worldToScreen(this.sim.human.x, this.sim.human.y, this.sim.human.z);

    const dist = this.sim.getHumanDistance();
    const isRecommended = dist >= 3.0 && dist <= 5.0;

    ctx.strokeStyle = isRecommended ? 'rgba(52, 211, 153, 0.7)' : 'rgba(251, 191, 36, 0.7)';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 5]);

    ctx.beginPath();
    ctx.moveTo(lampPos.x, lampPos.y);
    ctx.lineTo(humanPos.x, humanPos.y);
    ctx.stroke();
    ctx.setLineDash([]);

    // Distance Label
    const midX = (lampPos.x + humanPos.x) / 2;
    const midY = (lampPos.y + humanPos.y) / 2;

    const label = `${dist.toFixed(1)}m ${isRecommended ? '✓ Optimal (3-5m)' : '⚠ Close (<3m)'}`;
    ctx.font = '11px "JetBrains Mono", monospace';
    const textW = ctx.measureText(label).width;

    ctx.fillStyle = 'rgba(10, 15, 30, 0.85)';
    ctx.fillRect(midX - textW / 2 - 6, midY - 14, textW + 12, 20);
    ctx.strokeStyle = isRecommended ? '#10b981' : '#f59e0b';
    ctx.strokeRect(midX - textW / 2 - 6, midY - 14, textW + 12, 20);

    ctx.fillStyle = isRecommended ? '#34d399' : '#fbbf24';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label, midX, midY - 4);
  }

  drawHumanHost(ctx, timeNow) {
    const pos = this.worldToScreen(this.sim.human.x, this.sim.human.y, this.sim.human.z);
    const scale = pos.scale;

    // Body warmth halo (37°C)
    const heatGrad = ctx.createRadialGradient(pos.x, pos.y, 4, pos.x, pos.y, 1.2 * scale);
    heatGrad.addColorStop(0, 'rgba(239, 68, 68, 0.35)');
    heatGrad.addColorStop(0.6, 'rgba(249, 115, 22, 0.12)');
    heatGrad.addColorStop(1, 'rgba(239, 68, 68, 0)');
    ctx.fillStyle = heatGrad;
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 1.2 * scale, 0, Math.PI * 2);
    ctx.fill();

    // Human avatar icon
    ctx.fillStyle = '#f43f5e';
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 14, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Heartbeat pulse ring
    const pulse = (Math.sin(timeNow * 0.005) + 1) * 0.5;
    ctx.strokeStyle = `rgba(244, 63, 94, ${0.8 - pulse * 0.6})`;
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, 14 + pulse * 12, 0, Math.PI * 2);
    ctx.stroke();

    // Label
    ctx.font = 'bold 11px Inter, sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.textAlign = 'center';
    ctx.fillText('Human Host (37°C)', pos.x, pos.y + 28);
  }

  drawInsects(ctx, timeNow) {
    const scale = this.mode === 'topdown'
      ? Math.min(this.canvas.width / this.sim.room.width, this.canvas.height / this.sim.room.length)
      : Math.min(this.canvas.width / this.sim.room.width, this.canvas.height / this.sim.room.height);

    for (const bug of this.sim.insects) {
      if (bug.state === 'trapped') continue;

      const scr = this.worldToScreen(bug.x, bug.y, bug.z);

      // Insect trails
      if (this.showInsectTrails && bug.state === 'flying') {
        let history = this.trailHistory.get(bug.id);
        if (!history) {
          history = [];
          this.trailHistory.set(bug.id, history);
        }
        history.push({ x: scr.x, y: scr.y });
        if (history.length > 8) history.shift();

        if (history.length > 2) {
          ctx.strokeStyle = bug.speciesDef.color + '44';
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(history[0].x, history[0].y);
          for (let p = 1; p < history.length; p++) {
            ctx.lineTo(history[p].x, history[p].y);
          }
          ctx.stroke();
        }
      }

      // Draw bug body & animated wings
      ctx.save();
      ctx.translate(scr.x, scr.y);

      // Angle facing velocity
      const heading = this.mode === 'topdown'
        ? Math.atan2(bug.vz, bug.vx)
        : Math.atan2(-bug.vy, bug.vx);

      ctx.rotate(heading);

      const size = 5 * bug.speciesDef.size;
      const wingFlap = Math.sin(bug.wingPhase) * 6;

      // Species-specific silhouette
      ctx.fillStyle = bug.speciesDef.color;

      if (bug.species === 'moth') {
        // Moth: triangular wings
        ctx.beginPath();
        ctx.ellipse(0, 0, size * 1.2, size * 0.7, 0, 0, Math.PI * 2);
        ctx.fill();

        // White fluttering wings
        ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(-size, -size * 1.5 + wingFlap);
        ctx.lineTo(size * 0.8, -size * 1.2);
        ctx.closePath();
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(-size, size * 1.5 - wingFlap);
        ctx.lineTo(size * 0.8, size * 1.2);
        ctx.closePath();
        ctx.fill();
      } else if (bug.species === 'mosquito') {
        // --- ANATOMICALLY AUTHENTIC MOSQUITO IN 2D ---
        const mSize = size * 1.25;

        // 1. Long Spindly Articulated Legs (6 legs with high knee bends and trailing tarsi)
        ctx.strokeStyle = '#334155';
        ctx.lineWidth = 1.0;

        // Front Legs (bent forward)
        ctx.beginPath();
        ctx.moveTo(mSize * 0.2, -mSize * 0.3);
        ctx.lineTo(mSize * 0.8, -mSize * 1.2);
        ctx.lineTo(mSize * 1.4, -mSize * 1.6);
        ctx.moveTo(mSize * 0.2, mSize * 0.3);
        ctx.lineTo(mSize * 0.8, mSize * 1.2);
        ctx.lineTo(mSize * 1.4, mSize * 1.6);
        ctx.stroke();

        // Middle Legs (spread outward & back)
        ctx.beginPath();
        ctx.moveTo(0, -mSize * 0.35);
        ctx.lineTo(-mSize * 0.4, -mSize * 1.8);
        ctx.lineTo(-mSize * 0.2, -mSize * 2.5);
        ctx.moveTo(0, mSize * 0.35);
        ctx.lineTo(-mSize * 0.4, mSize * 1.8);
        ctx.lineTo(-mSize * 0.2, mSize * 2.5);
        ctx.stroke();

        // Hind Legs (Extra-long, arching back and trailing far behind in flight!)
        const legWave = Math.sin(bug.wingPhase * 0.2) * 2;
        ctx.strokeStyle = '#475569';
        ctx.beginPath();
        ctx.moveTo(-mSize * 0.4, -mSize * 0.3);
        ctx.lineTo(-mSize * 1.5, -mSize * 1.5 + legWave);
        ctx.lineTo(-mSize * 3.2, -mSize * 2.0 + legWave);
        ctx.moveTo(-mSize * 0.4, mSize * 0.3);
        ctx.lineTo(-mSize * 1.5, mSize * 1.5 - legWave);
        ctx.lineTo(-mSize * 3.2, mSize * 2.0 - legWave);
        ctx.stroke();

        // 2. Segmented Striped Abdomen (Alternating dark charcoal & silver-white rings)
        const segCount = 6;
        for (let s = 0; s < segCount; s++) {
          const segX = -mSize * 0.4 - s * (mSize * 0.38);
          const segW = mSize * 0.42 * (1 - s * 0.1);
          const segH = mSize * 0.36 * (1 - s * 0.12);

          ctx.fillStyle = (s % 2 === 1) ? '#e2e8f0' : '#1c1917'; // striped!
          ctx.beginPath();
          ctx.ellipse(segX, 0, segW, segH, 0, 0, Math.PI * 2);
          ctx.fill();
        }

        // 3. Humpbacked Thorax (Scutum)
        ctx.fillStyle = '#262626';
        ctx.beginPath();
        ctx.ellipse(0, 0, mSize * 0.65, mSize * 0.48, 0, 0, Math.PI * 2);
        ctx.fill();

        // White dorsal stripe on thorax (Aedes tiger mosquito)
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(-mSize * 0.3, -1, mSize * 0.6, 2);

        // 4. Head with Compound Eyes
        ctx.fillStyle = '#1c1917';
        ctx.beginPath();
        ctx.arc(mSize * 0.65, 0, mSize * 0.32, 0, Math.PI * 2);
        ctx.fill();

        // Black compound eyes
        ctx.fillStyle = '#020617';
        ctx.beginPath();
        ctx.arc(mSize * 0.72, -mSize * 0.16, mSize * 0.14, 0, Math.PI * 2);
        ctx.arc(mSize * 0.72, mSize * 0.16, mSize * 0.14, 0, Math.PI * 2);
        ctx.fill();

        // 5. Piercing Needle Proboscis (Long & sharp forward stylet)
        ctx.strokeStyle = '#f8fafc';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(mSize * 0.85, 0);
        ctx.lineTo(mSize * 2.6, 0);
        ctx.stroke();

        // Antennae (Branching sensory hairs)
        ctx.strokeStyle = '#94a3b8';
        ctx.lineWidth = 0.8;
        ctx.beginPath();
        ctx.moveTo(mSize * 0.75, -mSize * 0.1);
        ctx.lineTo(mSize * 1.8, -mSize * 0.7);
        ctx.moveTo(mSize * 0.75, mSize * 0.1);
        ctx.lineTo(mSize * 1.8, mSize * 0.7);
        ctx.stroke();

        // 6. Elongated Translucent Wings
        ctx.fillStyle = 'rgba(186, 230, 253, 0.75)';
        ctx.strokeStyle = 'rgba(125, 211, 252, 0.9)';
        ctx.lineWidth = 0.8;

        // Left Wing
        ctx.beginPath();
        ctx.ellipse(-mSize * 0.1, -mSize * 1.0 + wingFlap * 0.6, mSize * 1.4, mSize * 0.42, -0.35, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();

        // Right Wing
        ctx.beginPath();
        ctx.ellipse(-mSize * 0.1, mSize * 1.0 - wingFlap * 0.6, mSize * 1.4, mSize * 0.42, 0.35, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      } else {
        // Fruit fly / housefly: oval body with compact wings
        ctx.beginPath();
        ctx.ellipse(0, 0, size, size * 0.6, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
        ctx.beginPath();
        ctx.ellipse(-1, -size * 0.8 + wingFlap * 0.4, size * 0.7, size * 0.35, -0.3, 0, Math.PI * 2);
        ctx.fill();
        ctx.beginPath();
        ctx.ellipse(-1, size * 0.8 - wingFlap * 0.4, size * 0.7, size * 0.35, 0.3, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.restore();
    }
  }

  drawElectricDischarges(ctx) {
    for (const disc of this.sim.activeDischarges) {
      const pStart = this.worldToScreen(disc.startX, disc.startY, disc.startZ);
      const pEnd = this.worldToScreen(disc.endX, disc.endY, disc.endZ);

      // Branched procedural lightning bolt
      ctx.strokeStyle = '#ffffff';
      ctx.shadowColor = '#00f5ff';
      ctx.shadowBlur = 12;
      ctx.lineWidth = 2.5;

      ctx.beginPath();
      ctx.moveTo(pStart.x, pStart.y);

      // 3 intermediate jagged steps
      const steps = 4;
      for (let s = 1; s < steps; s++) {
        const factor = s / steps;
        const jx = pStart.x + (pEnd.x - pStart.x) * factor + (Math.random() - 0.5) * 16;
        const jy = pStart.y + (pEnd.y - pStart.y) * factor + (Math.random() - 0.5) * 16;
        ctx.lineTo(jx, jy);
      }
      ctx.lineTo(pEnd.x, pEnd.y);
      ctx.stroke();

      ctx.shadowBlur = 0; // reset

      // Draw spark particles
      for (const sp of disc.sparks) {
        if (sp.life <= 0) continue;
        const pSpark = this.worldToScreen(sp.x, sp.y, sp.z);
        ctx.fillStyle = Math.random() > 0.5 ? '#fff' : '#e056fd';
        ctx.beginPath();
        ctx.arc(pSpark.x, pSpark.y, 2.2, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  drawLamp(ctx, timeNow) {
    const pos = this.worldToScreen(this.sim.lamp.x, this.sim.lamp.y, this.sim.lamp.z);
    const scale = pos.scale;
    const wl = this.sim.getWavelengthData();
    const trap = this.sim.getTrapData();

    const lampR = this.sim.lamp.radius * scale;
    const gridR = this.sim.lamp.gridRadius * scale;

    ctx.save();
    ctx.translate(pos.x, pos.y);

    if (this.mode === 'topdown') {
      // Top-Down concentric view:
      // Outer safety slotted cage
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(0, 0, lampR, 0, Math.PI * 2);
      ctx.stroke();

      // Radial safety ribs (finger guard slots)
      ctx.lineWidth = 1.5;
      for (let a = 0; a < 16; a++) {
        const theta = (a / 16) * Math.PI * 2;
        ctx.beginPath();
        ctx.moveTo(Math.cos(theta) * (lampR * 0.7), Math.sin(theta) * (lampR * 0.7));
        ctx.lineTo(Math.cos(theta) * lampR, Math.sin(theta) * lampR);
        ctx.stroke();
      }

      // Internal Electrified Galvanized Wire Grid (or Fan)
      if (this.sim.lamp.trapType === 'zapper' || this.sim.lamp.trapType === 'solar') {
        ctx.strokeStyle = 'rgba(224, 86, 253, 0.75)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.arc(0, 0, gridR, 0, Math.PI * 2);
        ctx.stroke();

        // Inner secondary electro-grid
        ctx.beginPath();
        ctx.arc(0, 0, gridR * 0.7, 0, Math.PI * 2);
        ctx.stroke();
      } else if (this.sim.lamp.trapType === 'suction') {
        // Spinning Fan Blades
        const bladeAngle = (timeNow * 0.015) % (Math.PI * 2);
        ctx.fillStyle = 'rgba(0, 245, 255, 0.8)';
        for (let b = 0; b < 5; b++) {
          const ba = bladeAngle + (b / 5) * Math.PI * 2;
          ctx.beginPath();
          ctx.arc(Math.cos(ba) * (lampR * 0.45), Math.sin(ba) * (lampR * 0.45), 6, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      // Central UV Light Core (365nm glow)
      if (this.sim.lamp.isOn) {
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = wl.color;
        ctx.shadowBlur = 24;
        ctx.beginPath();
        ctx.arc(0, 0, lampR * 0.35, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }
    } else {
      // Side Cross-Section View:
      const lampH = 0.65 * scale;
      const lampHalfW = lampR;

      // Hanging Suspension Cord from Ceiling
      const ceilingScr = this.worldToScreen(this.sim.lamp.x, this.sim.room.height, this.sim.lamp.z);
      ctx.strokeStyle = '#94a3b8';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(0, -lampH / 2);
      ctx.lineTo(0, ceilingScr.y - pos.y);
      ctx.stroke();

      // Top Hood / Roof of Lamp
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.moveTo(-lampHalfW * 1.3, -lampH / 2);
      ctx.lineTo(lampHalfW * 1.3, -lampH / 2);
      ctx.lineTo(0, -lampH / 2 - 14);
      ctx.closePath();
      ctx.fill();
      ctx.strokeStyle = '#475569';
      ctx.stroke();

      // Outer Cage Slotted Grill
      ctx.strokeStyle = '#64748b';
      ctx.lineWidth = 1.5;
      for (let s = -lampHalfW; s <= lampHalfW; s += 8) {
        ctx.beginPath();
        ctx.moveTo(s, -lampH / 2);
        ctx.lineTo(s, lampH / 2 - 16);
        ctx.stroke();
      }

      // Central UV Tube
      if (this.sim.lamp.isOn) {
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = wl.color;
        ctx.shadowBlur = 20;
        ctx.fillRect(-6, -lampH / 2 + 10, 12, lampH - 32);
        ctx.shadowBlur = 0;
      }

      // Bottom Removable Catch Tray (Slide 6 & 11)
      ctx.fillStyle = '#0f172a';
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.fillRect(-lampHalfW * 1.1, lampH / 2 - 16, lampHalfW * 2.2, 18);
      ctx.strokeRect(-lampHalfW * 1.1, lampH / 2 - 16, lampHalfW * 2.2, 18);

      // Trapped Bugs Pile in Tray
      const trappedCount = this.sim.stats.totalTrapped;
      if (trappedCount > 0) {
        ctx.fillStyle = '#94a3b8';
        const pileDots = Math.min(24, trappedCount);
        for (let d = 0; d < pileDots; d++) {
          const dx = (Math.random() - 0.5) * (lampHalfW * 1.8);
          const dy = lampH / 2 - 10 + (Math.random() - 0.5) * 6;
          ctx.beginPath();
          ctx.arc(dx, dy, 1.5, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    }

    ctx.restore();
  }

  drawHUD(ctx, w, h) {
    // Top-Left View & Scientific Info Badge
    ctx.font = 'bold 12px Inter, sans-serif';
    ctx.fillStyle = '#f8fafc';
    ctx.textAlign = 'left';
    ctx.textBaseline = 'top';

    const modeText = this.mode === 'topdown'
      ? '2D TOP-DOWN TACTICAL RADAR'
      : '2D SIDE ELEVATION CROSS-SECTION';

    ctx.fillStyle = 'rgba(15, 23, 42, 0.8)';
    ctx.fillRect(16, 16, 260, 48);
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.2)';
    ctx.strokeRect(16, 16, 260, 48);

    ctx.fillStyle = '#a855f7';
    ctx.fillText(modeText, 26, 24);

    ctx.font = '11px Inter, sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText(`Drag Lamp or Human to test 3-5m spacing`, 26, 42);

    // Bottom-Left Interactive Mosquito & Environment Legend
    ctx.fillStyle = 'rgba(15, 23, 42, 0.88)';
    ctx.fillRect(16, h - 90, 310, 74);
    ctx.strokeStyle = 'rgba(148, 163, 184, 0.25)';
    ctx.strokeRect(16, h - 90, 310, 74);

    ctx.font = 'bold 11px Inter, sans-serif';
    ctx.fillStyle = '#c084fc';
    ctx.fillText('🦟 Target: Mosquitoes Only (Culicidae)', 26, h - 74);

    ctx.font = '10px Inter, sans-serif';
    ctx.fillStyle = '#94a3b8';
    ctx.fillText('• 365nm UV Phototaxis (94% pull) & 37°C Thermal Mimicry', 26, h - 57);

    const envLabel = this.isDayMode
      ? '☀️ Day Mode: Sunlight washes UV contrast (Slide 11)'
      : '🌙 Night Mode: Maximum UV lure contrast & peak catch';
    ctx.fillStyle = this.isDayMode ? '#fde047' : '#38bdf8';
    ctx.fillText(envLabel, 26, h - 40);
  }
}
